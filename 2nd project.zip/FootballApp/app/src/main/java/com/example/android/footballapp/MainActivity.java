package com.example.android.footballapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    int scorePlayerA = 0;
    int scorePlayerB = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayForPlayerA(0);
        displayForPlayerB(0);
    }

    /**
     * Adds three points for Player A.
     */
    public void addThreeForPlayerA (View v) {
        scorePlayerA = scorePlayerA + 3;
        displayForPlayerA(scorePlayerA);
    }

    /**
     * Adds two points for Player A.
     */
    public void addTwoForPlayerA (View v) {
        scorePlayerA = scorePlayerA + 2;
        displayForPlayerA(scorePlayerA);
    }

    /**
     * Adds one point for Player A.
     */
    public void addOneForPlayerA (View v) {
        scorePlayerA = scorePlayerA + 1;
        displayForPlayerA(scorePlayerA);
    }

    /**
     * Takes five points from Player A.
     */
    public void takeFiveFromPlayerA (View v) {
        scorePlayerA = scorePlayerA - 5;
        displayForPlayerA(scorePlayerA);
    }

    /**
     * Takes ten points from Player A.
     */
    public void takeTenFromPlayerA (View v) {
        scorePlayerA = scorePlayerA - 5;
        displayForPlayerA(scorePlayerA);
    }

    /**
     * Adds three points for Player B.
     */
    public void addThreeForPlayerB (View v) {
        scorePlayerB = scorePlayerB + 3;
        displayForPlayerA(scorePlayerB);
    }

    /**
     * Adds two points for Player B.
     */
    public void addTwoForPlayerB (View v) {

        displayForPlayerA(2);
    }

    /**
     * Adds one point for Player B.
     */
    public void addOneForPlayerB (View v) {

        displayForPlayerB(1);
    }

    /**
     * Takes five points from Player B.
     */
    public void takeFiveFromPlayerB (View v) {

        displayForPlayerB(-5);
    }

    /**
     * Takes ten points from Player B.
     */
    public void takeTenFromPlayerB (View v) {

        displayForPlayerB(-10);
    }

    /**
     * Resets score for both teams.
     */
    public void resetScore(View v) {
        scorePlayerA = 0;
        scorePlayerB = 0;
        displayForPlayerA(scorePlayerA);
        displayForPlayerB(scorePlayerB);
    }


    /**
     * Displays the start score for Player A.
     */
    public void displayForPlayerA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.player_a_score);
        scoreView.setText(String.valueOf(score));
    }
    /**
     * Displays the start score for Player B.
     */
    public void displayForPlayerB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.player_b_score);
        scoreView.setText(String.valueOf(score));
    }

    }


